HUAYKINMAIMOD PORTABLE 8.2 - MOCK ALL-IN-ONE (ENGLISH)

What this package is
---------------------
This is a self-contained MOCK edition of HuayKinMaiMod for testing and demo.
It includes a mock HuayKinMaiMod_Full_Build_Final.zip (index.php + assets) and a bundled PowerShell downloader for PHP 8.2.

How to use
----------
1. Extract the ZIP to any folder (e.g., C:\HuayKinMaiMod_portable)
2. Double-click AUTO_RUN_HUAYKINMAIMOD_Portable.bat
   - The script will extract the mock project, download PHP 8.2 if needed (requires internet), start PHP built-in server, and open the demo page.

Notes
-----
- This is a MOCK edition to allow you to test the portable runner and UI locally without providing your real project ZIP.
- If you want me to create a true All-in-One including your real HuayKinMaiMod_Full_Build_Final.zip, upload the ZIP here and I will rebuild the package and send it to you.
- The downloader uses a fixed PHP filename (php-8.2.29) as of mid-2025. If the URL changes, edit download_php.ps1 to the correct file.

Created automatically by assistant for Woravej
