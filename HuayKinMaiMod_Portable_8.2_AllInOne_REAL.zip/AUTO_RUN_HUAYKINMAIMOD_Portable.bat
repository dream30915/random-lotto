@echo off
chcp 65001 >nul
title HUAYKINMAIMOD PORTABLE AUTO RUN (FINAL FIX)
color 0A

setlocal EnableDelayedExpansion

echo ===============================================
echo    HUAYKINMAIMOD PORTABLE AUTO RUN (FINAL FIX)
echo ===============================================
echo.

set "root=%~dp0"
set "phpdir=%root%php"
set "phpexe=%phpdir%\php.exe"
set "zip=%root%HuayKinMaiMod_Full_Build_Final.zip"
set "extract=%root%HuayKinMaiMod_Extracted"

:: ตรวจไฟล์ ZIP
if not exist "%zip%" (
    echo [ERROR] Missing file: HuayKinMaiMod_Full_Build_Final.zip
    pause
    exit /b
)

:: ตรวจ PHP
if not exist "%phpexe%" (
    echo [INFO] PHP not found, downloading PHP 8.2.25 NTS...
    powershell -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://windows.php.net/downloads/releases/archives/php-8.2.25-nts-Win32-vs16-x64.zip' -OutFile '%root%php.zip'"
    powershell -Command "Expand-Archive -Path '%root%php.zip' -DestinationPath '%root%' -Force"
    del "%root%php.zip" >nul 2>&1

    for /d %%D in ("%root%php-8.2*") do (
        if not exist "%phpdir%" mkdir "%phpdir%"
        echo Moving PHP files from %%~nxD ...
        xcopy "%%D\*" "%phpdir%\" /E /I /Y >nul
        rmdir /s /q "%%D"
        goto movedone
    )
    :movedone
)

if not exist "%phpexe%" (
    echo [ERROR] PHP installation failed.
    pause
    exit /b
)

:: ลบของเก่าก่อน
if exist "%extract%" (
    echo Removing old extracted folder...
    rmdir /s /q "%extract%"
)

:: แตกไฟล์ ZIP
echo Extracting ZIP...
powershell -Command "Expand-Archive -Path '%zip%' -DestinationPath '%extract%' -Force"

if not exist "%extract%\index.php" (
    echo [ERROR] index.php not found after extraction.
    pause
    exit /b
)

cd /d "%extract%"

:: ค้นหาพอร์ตว่าง 8080-8083
set "port="
for %%P in (8080 8081 8082 8083) do (
    netstat -ano | find "LISTENING" | find "%%P" >nul
    if errorlevel 1 (
        set "port=%%P"
        goto foundport
    )
)

echo [ERROR] No available port (8080–8083)
pause
exit /b

:foundport
echo Using port !port!
echo.

:: รัน PHP server
start "" "%phpexe%" -S localhost:!port! -t "%extract%"
timeout /t 2 >nul

:: เปิดเว็บ
echo Opening browser...
start "" "http://localhost:!port!/index.php"

echo.
echo ===============================================
echo 🚀 Website started successfully on port !port!
echo URL: http://localhost:!port!/index.php
echo ===============================================
echo.
pause
exit /b
