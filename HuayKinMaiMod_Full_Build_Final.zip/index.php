<?php
// Simple mock HuayKinMaiMod random image generator
session_start();
function rand_number() {
    return rand(0,999999);
}
$number = isset($_GET['n']) ? htmlspecialchars($_GET['n']) : rand_number();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>HUAYKINMAIMOD - Random Poster</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
  <img src="assets/logo.png" class="logo" alt="logo">
  <div class="card">
    <h1>HUAYKINMAIMOD</h1>
    <p class="num"><?php echo str_pad($number,6,'0',STR_PAD_LEFT); ?></p>
    <div class="controls">
      <a class="btn" href="?n=<?php echo rand_number(); ?>">Generate</a>
      <a class="btn" href="download.php?n=<?php echo $number; ?>">Download Poster</a>
    </div>
    <p class="note">Portable Mock — PHP 8.2</p>
  </div>
</div>
</body>
</html>
