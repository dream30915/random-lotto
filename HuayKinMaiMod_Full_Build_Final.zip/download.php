<?php
// Simple image poster generator for download
if (!isset($_GET['n'])) { header("Location: index.php"); exit; }
$n = htmlspecialchars($_GET['n']);
$im = imagecreatetruecolor(800,600);
$bg = imagecolorallocate($im, 58,25,73); // purple
$gold = imagecolorallocate($im, 212,175,55);
$white = imagecolorallocate($im,255,255,255);
imagefilledrectangle($im,0,0,800,600,$bg);
$font = __DIR__ . '/assets/arial.ttf';
// If font missing, use built-in small font
if (file_exists($font)) {
  imagettftext($im, 80, 0, 120, 320, $gold, $font, $n);
} else {
  imagestring($im, 5, 300, 260, $n, $gold);
}
header('Content-Type: image/png');
imagepng($im);
imagedestroy($im);
?>